package com.wcp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.wcp.domain.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {

}
