package com.wcp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.wcp.domain.Category;

public interface CategoryRepository extends CrudRepository<Category, Long> {

}
